const globeVar = "http://localhost:8000/api/";
export default globeVar;